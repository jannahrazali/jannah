// UseMon_DSET3

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GummyStore extends JDialog {
    private JTextField tfEmail;
    private JPasswordField pfPassword;
    private JButton OKButton;
    private JButton cancelButton;
    private JLabel tfpass;
    private JPanel loginPanel;
    private JPanel hello;

    private User user;

    public GummyStore(JFrame parent) {
        super(parent);
        setTitle("Login");
        setContentPane(hello);
        setMinimumSize(new Dimension(450, 474));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        OKButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = tfEmail.getText();
                String password = String.valueOf(pfPassword.getPassword());

                user = getAuthenticatedUser(email, password);

                if (user != null) {
                    saveData(user);
                    openMenuInterface(); // Open the Menu interface after successful login
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(GummyStore.this,
                            "Authentication Failed",
                            "Try again",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetSystem();
            }
        });

        setVisible(true);
    }

    private void saveData(User user) {
        // Implement your data-saving logic here
        // For example, you can store the data in a file or a database
        // You might want to display a message confirming the data has been saved
        JOptionPane.showMessageDialog(GummyStore.this,
                "Data saved successfully for user: " + user.getEmail(),
                "Success",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void resetSystem() {
        // Implement your system reset logic here
        // This might involve clearing input fields or resetting any state
        tfEmail.setText("");
        pfPassword.setText("");
        user = null;  // Reset the user data
    }

    private User getAuthenticatedUser(String email, String password) {
        // For testing purposes, let's consider any input as valid
        return new User(email, password);
    }

    private void openMenuInterface() {
        JFrame menuFrame = new JFrame("Menu");
        menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        menuFrame.setContentPane(new Menu().background);
        menuFrame.pack();
        menuFrame.setVisible(true);
    }

    public static void main(String[] args) {
        GummyStore gummyStore = new GummyStore(null);
    }
}

// Define a simple User class
class User {
    private String email;
    private String password;

    public User(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }
}
