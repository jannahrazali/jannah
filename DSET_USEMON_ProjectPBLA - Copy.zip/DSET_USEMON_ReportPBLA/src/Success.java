// UseMon_DSET3

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Success {
    public JPanel success;
    private JProgressBar progressBar1;
    private JLabel received;
    private JLabel wait;

    public Success() {
        // Example: start a timer to update the progress bar every 200 milliseconds (adjust as needed)
        Timer timer = new Timer(200, new ActionListener() {
            private int progressValue = 0;

            @Override
            public void actionPerformed(ActionEvent e) {
                if (progressValue <= 100) {
                    setProgress(progressValue);
                    progressValue += 10; // Increment the progress value (adjust as needed)
                } else {
                    ((Timer) e.getSource()).stop(); // Stop the timer when progress reaches 100%
                    showThankYouMessage();
                }
            }
        });
        timer.start();
    }

    // Method to set the progress value for the progress bar
    private void setProgress(int value) {
        progressBar1.setValue(value);
    }

    // Method to show the "Thank You" message
    private void showThankYouMessage() {
        Thankyou thankyouFrame = new Thankyou();
        JFrame thankyouJFrame = new JFrame("Thank You");
        thankyouJFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        thankyouJFrame.setContentPane(thankyouFrame.thankyou);
        thankyouJFrame.pack();
        thankyouJFrame.setVisible(true);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Success");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(new Success().success);
        frame.pack();
        frame.setVisible(true);
    }
}
