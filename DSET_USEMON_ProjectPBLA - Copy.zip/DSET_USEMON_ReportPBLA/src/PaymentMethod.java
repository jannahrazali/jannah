// UseMon_DSET3

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PaymentMethod {
    private JButton continuePaymentButton;
    private JButton cancelButton;
    private JRadioButton debitCreditCardRadioButton;
    private JRadioButton onlineBankingRadioButton;
    private JRadioButton cashRadioButton;
    public JPanel payment;
    private JLabel choose;
    private JLabel paymentLabel;

    public PaymentMethod() {
        debitCreditCardRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleDebitCreditCardSelected();
            }
        });

        onlineBankingRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleOnlineBankingSelected();
            }
        });

        cashRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleCashSelected();
            }
        });

        continuePaymentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleContinuePayment();
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleCancel();
            }
        });
    }

    // Example actions for each payment method
    private void handleDebitCreditCardSelected() {
        // Add logic for debit/credit card selected
        paymentLabel.setText("Debit/Credit Card Selected");
    }

    private void handleOnlineBankingSelected() {
        // Add logic for online banking selected
        paymentLabel.setText("Online Banking Selected");
    }

    private void handleCashSelected() {
        // Add logic for cash selected
        paymentLabel.setText("Cash Selected");
    }

    private void handleContinuePayment() {
        // Add logic for continue payment button
        Success successFrame = new Success();
        JFrame successJFrame = new JFrame("Success");
        successJFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        successJFrame.setContentPane(successFrame.success);
        successJFrame.pack();
        successJFrame.setVisible(true);
    }

    private void handleCancel() {
        // Add logic for cancel button
        int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to cancel the transaction?", "Cancel Transaction", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, "Transaction Cancelled");
            // Add any additional logic if needed
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Payment Method");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(new PaymentMethod().payment);
        frame.pack();
        frame.setVisible(true);
    }
}
