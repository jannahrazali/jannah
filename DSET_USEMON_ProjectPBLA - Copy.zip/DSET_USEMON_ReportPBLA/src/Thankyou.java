// UseMon_DSET3

import javax.swing.*;

public class Thankyou {
    public JPanel thankyou;
    private JLabel successfully;
    private JLabel thx;
}
