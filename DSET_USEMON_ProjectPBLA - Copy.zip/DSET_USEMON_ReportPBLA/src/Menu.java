// UseMon_DSET3

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu {
    public JPanel background;
    private JSpinner quantityworm;
    private JSpinner quantitymarshmallow;
    private JSpinner quantitycookies;
    private JSpinner quantitybear;
    private JButton addButton;
    private JLabel price1;
    private JLabel price2;
    private JLabel price3;
    private JLabel price4;
    private JTextField subtotal;
    private JButton clearButton;
    private JButton paymentButton;
    private JTextField tax;
    private JTextField total;
    private JLabel worms;
    private JLabel bears;
    private JLabel marshmellow;
    private JLabel cookie;

    // Prices for each item
    private final double PRICE_WORM = 6.00;
    private final double PRICE_MARSHMALLOW = 8.00;
    private final double PRICE_COOKIES = 7.00;
    private final double PRICE_BEAR = 5.00;

    // Tax rate (e.g., 5%)
    private final double TAX_RATE = 0.05;

    public Menu() {
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateSubtotal();
                calculateTax();
                calculateTotal();
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearInputs();
            }
        });

        paymentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPaymentMethodDialog();
            }
        });
    }

    // Helper method to calculate subtotal based on quantity and price
    private void calculateSubtotal() {
        int quantityWorm = (int) quantityworm.getValue();
        int quantityMarshmallow = (int) quantitymarshmallow.getValue();
        int quantityCookies = (int) quantitycookies.getValue();
        int quantityBear = (int) quantitybear.getValue();

        double subtotalValue = (quantityWorm * PRICE_WORM) +
                (quantityMarshmallow * PRICE_MARSHMALLOW) +
                (quantityCookies * PRICE_COOKIES) +
                (quantityBear * PRICE_BEAR);

        // Update the subtotal JTextField
        subtotal.setText(String.format("RM %.2f", subtotalValue));
    }

    // Helper method to calculate tax based on the subtotal
    private void calculateTax() {
        if (!subtotal.getText().isEmpty()) {
            double subtotalValue = Double.parseDouble(subtotal.getText().substring(3)); // Remove "RM " prefix
            double taxValue = subtotalValue * TAX_RATE;

            // Update the tax JTextField
            tax.setText(String.format("RM %.2f", taxValue));
        }
    }

    // Helper method to calculate total based on subtotal and tax
    private void calculateTotal() {
        if (!subtotal.getText().isEmpty() && !tax.getText().isEmpty()) {
            double subtotalValue = Double.parseDouble(subtotal.getText().substring(3)); // Remove "RM " prefix
            double taxValue = Double.parseDouble(tax.getText().substring(3)); // Remove "RM " prefix
            double totalValue = subtotalValue + taxValue;

            // Update the total JTextField
            total.setText(String.format("RM %.2f", totalValue));
        }
    }

    // Helper method to clear inputs
    private void clearInputs() {
        quantityworm.setValue(0);
        quantitymarshmallow.setValue(0);
        quantitycookies.setValue(0);
        quantitybear.setValue(0);
        subtotal.setText("");
        tax.setText("");
        total.setText("");
    }

    // Helper method to show PaymentMethod dialog
    private void showPaymentMethodDialog() {
        JFrame paymentFrame = new JFrame("Payment Method");
        paymentFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        paymentFrame.setContentPane(new PaymentMethod().payment);
        paymentFrame.pack();
        paymentFrame.setVisible(true);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Menu");
        frame.setContentPane(new Menu().background);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}

